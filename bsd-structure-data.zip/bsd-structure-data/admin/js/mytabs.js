
jQuery(document).ready(function ($) {
    $("#mytabs .hidden").removeClass('hidden');
    $("#mytabs").tabs({ active: 0 });
});


